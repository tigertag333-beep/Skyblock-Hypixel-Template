# SBSF — SkyBlock Assistant (Minecraft Java 26.2)

SBSF is a beginner-friendly, client-side Fabric template for early- and mid-game SkyBlock planning. Its dark category GUI uses an original SBSF layout inspired by the general organization patterns of popular configuration mods. It does not copy their code or branding.

## Features

- **`/sbsf` GUI** with Overview, HUD, Appearance, Skills, Progression, Slayer, Coin Goal, Reminder, and About categories.
- **Custom HUD:** toggle individual lines, choose Purple / Sky blue / Mint / Gold, compact spacing, and nudge or reset the position.
- **Early/mid-game progression checklist:** manually mark eight milestones (Bazaar access, End access, weapon/healing setup, accessories, minions, money method, collections/commissions, and armor upgrades). Checklist state is saved locally and shown as a HUD count.
- **Manual coin-goal calculator:** supports full numbers and K/M/B suffixes such as `1.5m`; calculates the remaining amount and shows your saved goal. It does not read or overwrite your live purse.
- **Personal reminder:** save a short note such as `Collect minions` or `Check Bazaar orders`.
- **Session timer:** elapsed time since this client-side mod session started, not total playtime.
- **Skill focus and contextual tips:** select a focus manually or use Auto detection based on held-item names. This is a heuristic, not a reliable game API.
- **Slayer helper:** best-effort parsing of visible sidebar text and an estimated spawn-progress line where recognizable text is present.
- **Idle reminder:** configurable delay (15 / 30 / 45 / 60 / 120 seconds).
- **Local settings:** JSON saved in `config/slayersforpros.json`. Existing settings files are normalized when newer options are added.
- **Explanatory comments:** main classes and customization points are documented beside the code.

## Commands

- `/sbsf` — open the settings GUI
- `/sbsf gui` — open the settings GUI
- `/sbsf hud` — toggle the HUD
- `/sfp` and `/sbst` — legacy aliases

## Requirements

- Minecraft Java Edition **26.2**
- Fabric Loader **0.19.3** or compatible 26.2 release
- Fabric API **0.161.0+26.2** (as set in `gradle.properties`)
- Java **25**
- Internet access on first build to download Gradle and dependencies

This uses Fabric Loom's non-remapping plugin (`net.fabricmc.fabric-loom`) for Minecraft 26.2. Its dependencies use the `implementation` configuration.

## Build on Bazzite / Linux

1. Extract the ZIP.
2. Open a terminal in the `sbsf` folder (the one containing `build.gradle`).
3. Verify Java 25 with `java -version`.
4. Run:

   ```bash
   chmod +x gradlew
   ./gradlew clean build
   ```

5. The installable mod JAR is **`build/libs/sbsf.jar`** inside your project folder. Gradle creates `build/libs` when the build runs; it is not part of the Loom cache.
6. Copy `sbsf.jar` into the `mods` folder for your Minecraft 26.2 Fabric instance and make sure that instance also has a matching Fabric API JAR.
7. Launch the instance and type `/sbsf` in a world.

For Windows, run `gradlew.bat clean build` from the project folder. The build is configured to output the main mod as `sbsf.jar` in the project's own `build/libs` directory, not in the Loom cache, regardless of the version number.

### Troubleshooting

- `Could not find method modImplementation()` — this project uses the non-remapping Loom plugin for 26.2; the dependencies should use `implementation`, not `modImplementation`.
- `invalid source release: 25` or `Unsupported class file major version` — select/install Java 25.
- `Could not find fabric-api` — verify the version in `gradle.properties` is available and matches Minecraft 26.2.
- `/sbsf` is unknown — verify you launched the correct Fabric 26.2 instance and installed `sbsf.jar` into that instance's `mods` directory.
- Mod fails to load — check Fabric Loader, Fabric API, Minecraft, and the latest crash report.

## Beginner code map

| File | Purpose |
|---|---|
| `SfpClient.java` | Client initialization, commands, tick tracking, and HUD registration. |
| `SfpScreen.java` | Category navigation, buttons, coin inputs, reminder editor, and GUI drawing. |
| `SfpHud.java` | Renders enabled HUD lines and the themed panel. |
| `SlayerTracker.java` | Reads visible scoreboard strings, estimates activity, tracks session time, and selects simple tips. |
| `SfpConfig.java` | Default settings, theme colors, progression checklist, and JSON persistence. |
| `fabric.mod.json` | Mod ID, display name, client entrypoint, and Minecraft/Fabric requirements. |
| `build.gradle` | Loom plugin, dependencies, Java 25, and the fixed `sbsf.jar` output filename. |
| `gradle.properties` | Minecraft, Fabric, Loom, mod version, and artifact base name. |

### Easy customization

- Change default settings in `SfpConfig.java`.
- Change checklist text in `SfpScreen.java`'s `PROGRESSION_GOALS` array. Keep eight entries so it matches `progressionDone` in `SfpConfig.java`.
- Add a HUD line in `SfpHud.render()` and add a matching config option if users should be able to hide it.
- Add a theme by extending the `THEMES` list in `SfpScreen.java` and the matching switch in `SfpConfig.accentColor()`.
- The config is local JSON; close Minecraft before editing it manually.

## Safety and limitations

SBSF is deliberately a local display and planning helper. It does not include macros, auto-clicking, movement/combat automation, packet manipulation, hidden server-data inspection, or remote profile scraping. Activity, purse/XP text, and slayer parsing are best-effort and may fail if the visible sidebar layout differs. The checklist is manually controlled; it does not verify milestone completion. Exact skill level / XP-to-next-level calculations and SkyCrypt integration are not included. No mod can be guaranteed permanently allowed by Hypixel; check current official rules before using mods on the server.

Useful references: https://docs.fabricmc.net/ · https://fabricmc.net/2026/06/15/262.html

SBSF is independent and is not affiliated with Hypixel, Mojang, Microsoft, SkyHanni, or Skyblocker.
