// Main entry point for the client-side mod.
// This file wires together commands, tick updates, and the HUD renderer.
package com.sfp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class SfpClient implements ClientModInitializer {
    // Runs once when Minecraft starts this client mod.
    // Load saved options first so the GUI and HUD use the user's preferences.
    @Override public void onInitializeClient() {
        SfpConfig.load();
        // Register /sbsf (main command), /sfp (legacy alias), and /sbst (template alias).
        // All commands are client-side; none of them sends gameplay actions to the server.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            for (String command : new String[]{"sbsf", "sfp", "sbst"}) {
                dispatcher.register(ClientCommands.literal(command)
                    .executes(ctx -> { openGui(); return 1; })
                    .then(ClientCommands.literal("gui").executes(ctx -> { openGui(); return 1; }))
                    .then(ClientCommands.literal("hud").executes(ctx -> {
                        SfpConfig.INSTANCE.hudEnabled = !SfpConfig.INSTANCE.hudEnabled;
                        SfpConfig.save();
                        Minecraft mc = Minecraft.getInstance();
                        if (mc.player != null) {
                            mc.player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                                "[SBSF] HUD " + (SfpConfig.INSTANCE.hudEnabled ? "enabled" : "disabled")));
                        }
                        return 1;
                    })));
            }
        });
        // Update trackers at the end of each client tick; the tracker throttles its own parsing.
        ClientTickEvents.END_CLIENT_TICK.register(SlayerTracker::tick);
        // Draw the custom HUD before chat so it appears as a normal in-game overlay.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("slayersforpros", "hud"), SfpHud::render);
    }
    // Open the screen on Minecraft's client thread, not directly from command registration.
    private static void openGui() {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> mc.gui.setScreen(new SfpScreen()));
    }
}
