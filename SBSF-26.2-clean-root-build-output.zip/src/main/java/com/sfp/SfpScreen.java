package com.sfp;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * An original, dark configuration screen inspired by the category-and-setting layouts common to
 * SkyHanni and Skyblocker. It uses SBSF's own colors, wording, and feature organization.
 *
 * Beginner note: init() creates buttons and text boxes; extractRenderState() draws the panels,
 * titles, and help text behind/on top of those widgets.
 */
public class SfpScreen extends Screen {
    private static final String[] CATEGORIES = {
            "Overview", "HUD", "Appearance", "Skills", "Progression", "Slayer", "Coin Goal", "Reminder", "About"
    };

    // A practical starter roadmap. These are suggestions, not mandatory goals or server-detected state.
    private static final String[] PROGRESSION_GOALS = {
            "Unlock Bazaar access",
            "Reach Combat XII / unlock the End",
            "Build an early weapon and healing setup",
            "Collect accessories and choose a power",
            "Increase minion slots and daily resources",
            "Choose one consistent money method",
            "Start a collection or commission routine",
            "Upgrade armor for your next milestone"
    };
    private static final String[] SKILLS = {
            "Auto", "Mining", "Fishing", "Farming", "Foraging", "Combat", "Enchanting", "Alchemy", "Taming"
    };
    private static final String[] THEMES = {"Purple", "Sky blue", "Mint", "Gold"};
    private static final int[] AFK_TIMEOUTS = {15, 30, 45, 60, 120};

    private String selected = "Overview";
    private EditBox currentCoinsInput;
    private EditBox targetCoinsInput;
    private EditBox reminderInput;
    private String goalStatus = "Enter your current coins and goal, then press Calculate.";
    private String reminderStatus = "Your reminder is saved only on this computer.";

    public SfpScreen() {
        super(Component.literal("Slayers For Pros"));
    }

    private int panelLeft() { return Math.max(8, (this.width - panelWidth()) / 2); }
    private int panelTop() { return Math.max(8, (this.height - panelHeight()) / 2); }
    private int panelWidth() { return Math.min(780, Math.max(300, this.width - 16)); }
    private int panelHeight() { return Math.min(460, Math.max(240, this.height - 16)); }
    private int contentX() { return panelLeft() + 190; }
    private int contentW() { return Math.max(100, panelWidth() - 208); }
    private int contentY() { return panelTop() + 111; }

    @Override
    protected void init() {
        clearWidgets();
        int left = panelLeft();
        int top = panelTop();
        int panelW = panelWidth();
        int contentX = contentX();
        int contentW = contentW();
        int navY = top + 91;

        // Left category rail, similar in structure to feature-oriented SkyBlock mod menus.
        for (String category : CATEGORIES) {
            final String name = category;
            String marker = selected.equals(name) ? "◆  " : "   ";
            addRenderableWidget(Button.builder(Component.literal(marker + name), button -> {
                selected = name;
                rebuildWidgets();
            }).bounds(left + 10, navY, 158, 22).build());
            navY += 26;
        }

        int y = contentY();
        SfpConfig c = SfpConfig.INSTANCE;
        switch (selected) {
            case "Overview" -> {
                addToggle(contentX, y, contentW, "Show the SBSF HUD", () -> c.hudEnabled, value -> c.hudEnabled = value);
                addToggle(contentX, y + 29, contentW, "Show the manual coin-goal line", () -> c.showGoal, value -> c.showGoal = value);
                addToggle(contentX, y + 58, contentW, "Show your saved reminder", () -> c.showReminder, value -> c.showReminder = value);
                addToggle(contentX, y + 87, contentW, "Show the session timer", () -> c.showSession, value -> c.showSession = value);
                addRenderableWidget(Button.builder(Component.literal("Open HUD settings →"), button -> {
                    selected = "HUD";
                    rebuildWidgets();
                }).bounds(contentX, y + 129, contentW, 22).build());
            }
            case "HUD" -> {
                addToggle(contentX, y, contentW, "Enable HUD", () -> c.hudEnabled, value -> c.hudEnabled = value);
                addToggle(contentX, y + 27, contentW, "Activity and focus", () -> c.showActivity, value -> c.showActivity = value);
                addToggle(contentX, y + 54, contentW, "Detected purse text", () -> c.showCoins, value -> c.showCoins = value);
                addToggle(contentX, y + 81, contentW, "Detected skill XP text", () -> c.showXp, value -> c.showXp = value);
                addToggle(contentX, y + 108, contentW, "Slayer and estimated spawn progress", () -> c.showSlayer, value -> c.showSlayer = value);
                addToggle(contentX, y + 135, contentW, "Tips and AFK reminder", () -> c.showTips, value -> c.showTips = value);
                addToggle(contentX, y + 162, contentW, "Session timer", () -> c.showSession, value -> c.showSession = value);
                addToggle(contentX, y + 189, contentW, "Manual coin goal", () -> c.showGoal, value -> c.showGoal = value);
                addToggle(contentX, y + 216, contentW, "Personal reminder", () -> c.showReminder, value -> c.showReminder = value);
                addToggle(contentX, y + 243, contentW, "Boss count this session", () -> c.showBossCount, value -> c.showBossCount = value);
                addToggle(contentX, y + 270, contentW, "Progression checklist count", () -> c.showProgression, value -> c.showProgression = value);
            }
            case "Appearance" -> {
                addRenderableWidget(Button.builder(Component.literal("HUD theme: " + c.hudTheme + "  ▸"), button -> {
                    c.hudTheme = nextOption(c.hudTheme, THEMES);
                    button.setMessage(Component.literal("HUD theme: " + c.hudTheme + "  ▸"));
                    SfpConfig.save();
                }).bounds(contentX, y, contentW, 22).build());
                addToggle(contentX, y + 31, contentW, "Compact HUD spacing", () -> c.compactHud, value -> c.compactHud = value);
                int halfW = (contentW - 6) / 2;
                addRenderableWidget(Button.builder(Component.literal("← Move left"), button -> moveHud(-8, 0))
                        .bounds(contentX, y + 72, halfW, 22).build());
                addRenderableWidget(Button.builder(Component.literal("Move right →"), button -> moveHud(8, 0))
                        .bounds(contentX + halfW + 6, y + 72, halfW, 22).build());
                addRenderableWidget(Button.builder(Component.literal("↑ Move up"), button -> moveHud(0, -8))
                        .bounds(contentX, y + 99, halfW, 22).build());
                addRenderableWidget(Button.builder(Component.literal("↓ Move down"), button -> moveHud(0, 8))
                        .bounds(contentX + halfW + 6, y + 99, halfW, 22).build());
                addRenderableWidget(Button.builder(Component.literal("Reset HUD position"), button -> {
                    c.hudX = 8; c.hudY = 8; SfpConfig.save();
                }).bounds(contentX, y + 130, contentW, 22).build());
            }
            case "Skills" -> {
                addRenderableWidget(Button.builder(Component.literal("Main skill focus: " + c.focusSkill + "  ▸"), button -> {
                    c.focusSkill = nextOption(c.focusSkill, SKILLS);
                    button.setMessage(Component.literal("Main skill focus: " + c.focusSkill + "  ▸"));
                    SfpConfig.save();
                }).bounds(contentX, y, contentW, 22).build());
                addToggle(contentX, y + 34, contentW, "Show contextual skill tips", () -> c.showTips, value -> c.showTips = value);
            }
            case "Progression" -> {
                // Click a milestone to mark it done. State is saved locally and can be reset anytime.
                for (int i = 0; i < PROGRESSION_GOALS.length; i++) {
                    final int goalIndex = i;
                    boolean done = c.progressionDone[i];
                    String label = (done ? "[✓] " : "[ ] ") + PROGRESSION_GOALS[i];
                    addRenderableWidget(Button.builder(Component.literal(label), button -> {
                        c.progressionDone[goalIndex] = !c.progressionDone[goalIndex];
                        button.setMessage(Component.literal((c.progressionDone[goalIndex] ? "[✓] " : "[ ] ")
                                + PROGRESSION_GOALS[goalIndex]));
                        SfpConfig.save();
                    }).bounds(contentX, y + 42 + i * 27, contentW, 22).build());
                }
                addRenderableWidget(Button.builder(Component.literal("Reset all milestones"), button -> {
                    java.util.Arrays.fill(c.progressionDone, false);
                    SfpConfig.save();
                    selected = "Progression";
                    rebuildWidgets();
                }).bounds(contentX, y + 264, contentW, 22).build());
            }
            case "Slayer" -> {
                addToggle(contentX, y, contentW, "Boss-ready chat reminder", () -> c.bossAlert, value -> c.bossAlert = value);
                addToggle(contentX, y + 30, contentW, "Display slayer progress on the HUD", () -> c.showSlayer, value -> c.showSlayer = value);
                addRenderableWidget(Button.builder(Component.literal("Reset session boss count"), button -> {
                    SlayerTracker.bossesKilled = 0;
                    SfpConfig.save();
                }).bounds(contentX, y + 73, contentW, 22).build());
            }
            case "Coin Goal" -> {
                currentCoinsInput = new EditBox(this.font, contentX, y + 15, contentW, 20, Component.literal("Current coins"));
                currentCoinsInput.setMaxLength(18);
                currentCoinsInput.setValue(Long.toString(c.currentCoins));
                addRenderableWidget(currentCoinsInput);
                targetCoinsInput = new EditBox(this.font, contentX, y + 62, contentW, 20, Component.literal("Target coins"));
                targetCoinsInput.setMaxLength(18);
                targetCoinsInput.setValue(Long.toString(c.targetCoins));
                addRenderableWidget(targetCoinsInput);
                addRenderableWidget(Button.builder(Component.literal("Calculate and save goal"), button -> calculateGoal())
                        .bounds(contentX, y + 96, contentW, 22).build());
            }
            case "Reminder" -> {
                reminderInput = new EditBox(this.font, contentX, y + 17, contentW, 20, Component.literal("Reminder text"));
                reminderInput.setMaxLength(80);
                reminderInput.setValue(c.reminder == null ? "" : c.reminder);
                addRenderableWidget(reminderInput);
                addRenderableWidget(Button.builder(Component.literal("Save reminder"), button -> saveReminder())
                        .bounds(contentX, y + 51, contentW, 22).build());
                addToggle(contentX, y + 86, contentW, "Show reminder on the HUD", () -> c.showReminder, value -> c.showReminder = value);
                addToggle(contentX, y + 115, contentW, "Enable inactivity reminder", () -> c.afkTips, value -> c.afkTips = value);
                addRenderableWidget(Button.builder(Component.literal("Idle reminder delay: " + c.afkTimeoutSeconds + "s  ▸"), button -> {
                    c.afkTimeoutSeconds = nextTimeout(c.afkTimeoutSeconds);
                    button.setMessage(Component.literal("Idle reminder delay: " + c.afkTimeoutSeconds + "s  ▸"));
                    SfpConfig.save();
                }).bounds(contentX, y + 144, contentW, 22).build());
            }
            default -> {
                // About page intentionally has no controls. The explanation is drawn below.
            }
        }

        // Persistent footer controls. Save is explicit as well as being called after individual changes.
        int footerY = top + panelHeight() - 31;
        addRenderableWidget(Button.builder(Component.literal("Save settings"), button -> SfpConfig.save())
                .bounds(contentX, footerY, Math.max(96, contentW - 104), 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
                .bounds(left + panelW - 88, footerY, 76, 20).build());
    }

    private void addToggle(int x, int y, int w, String label,
                           BooleanSupplier get, Consumer<Boolean> set) {
        addRenderableWidget(Button.builder(toggleText(label, get.getAsBoolean()), button -> {
            boolean next = !get.getAsBoolean();
            set.accept(next);
            button.setMessage(toggleText(label, next));
            SfpConfig.save();
        }).bounds(x, y, w, 22).build());
    }

    private static Component toggleText(String label, boolean enabled) {
        return Component.literal(label + "   " + (enabled ? "[ ON ]" : "[ OFF ]"));
    }

    private static int nextTimeout(int current) {
        for (int i = 0; i < AFK_TIMEOUTS.length; i++) {
            if (AFK_TIMEOUTS[i] == current) return AFK_TIMEOUTS[(i + 1) % AFK_TIMEOUTS.length];
        }
        return 30;
    }

    private static String nextOption(String current, String[] options) {
        for (int i = 0; i < options.length; i++) {
            if (options[i].equalsIgnoreCase(current)) return options[(i + 1) % options.length];
        }
        return options[0];
    }

    private static long parseCoins(String value) {
        if (value == null || value.isBlank()) return 0;
        // Accept full numbers (1000000), comma-separated numbers (1,000,000), and K/M/B suffixes.
        String normalized = value.replace(",", "").replace("_", "").trim().toLowerCase(Locale.ROOT);
        if (normalized.isEmpty()) return 0;
        double multiplier = 1.0;
        char last = normalized.charAt(normalized.length() - 1);
        if (last == 'k' || last == 'm' || last == 'b') {
            multiplier = switch (last) {
                case 'k' -> 1_000.0;
                case 'm' -> 1_000_000.0;
                default -> 1_000_000_000.0;
            };
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        try {
            double parsed = Double.parseDouble(normalized) * multiplier;
            if (!Double.isFinite(parsed) || parsed >= Long.MAX_VALUE) return Long.MAX_VALUE;
            return Math.max(0L, Math.round(parsed));
        } catch (NumberFormatException ignored) {
            return 0L;
        }
    }

    private void calculateGoal() {
        SfpConfig c = SfpConfig.INSTANCE;
        c.currentCoins = parseCoins(currentCoinsInput == null ? "0" : currentCoinsInput.getValue());
        c.targetCoins = parseCoins(targetCoinsInput == null ? "0" : targetCoinsInput.getValue());
        SfpConfig.save();
        long remaining = SfpConfig.coinsRemaining();
        goalStatus = remaining == 0
                ? "Goal reached — great work!"
                : String.format(Locale.ROOT, "You need %,d more coins.", remaining);
    }

    private void saveReminder() {
        SfpConfig.INSTANCE.reminder = reminderInput == null ? "" : reminderInput.getValue().trim();
        SfpConfig.save();
        reminderStatus = SfpConfig.INSTANCE.reminder.isBlank()
                ? "Reminder cleared."
                : "Saved reminder: " + SfpConfig.INSTANCE.reminder;
    }

    private void moveHud(int dx, int dy) {
        SfpConfig c = SfpConfig.INSTANCE;
        c.hudX = Math.max(2, Math.min(this.width - 180, c.hudX + dx));
        c.hudY = Math.max(2, Math.min(this.height - 80, c.hudY + dy));
        SfpConfig.save();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        int left = panelLeft();
        int top = panelTop();
        int panelW = panelWidth();
        int panelH = panelHeight();
        int accent = SfpConfig.accentColor();
        int sideRight = left + 178;

        // Let Minecraft draw its background and interactive controls first.
        super.extractRenderState(g, mouseX, mouseY, delta);

        // Draw only decorative areas that do not overlap controls, then outline the content panels.
        g.fill(left, top, left + panelW, top + 3, accent);
        g.fill(left + 8, top + 8, left + panelW - 8, top + 46, 0xFF20202B);
        g.outline(left + 5, top + 54, sideRight - left - 5, panelH - 90, 0xFF363642);
        g.outline(sideRight + 6, top + 54, panelW - (sideRight - left) - 13, panelH - 90, 0xFF363642);
        g.fill(left + 5, top + 54, left + 7, top + panelH - 36, accent);

        // Header, section captions, and helper copy are drawn after the widgets for legibility.
        g.text(this.font, "SBSF  /  SKYBLOCK ASSISTANT", left + 17, top + 15, 0xFFFFFFFF, true);
        g.text(this.font, "SKYBLOCK TOOLKIT  •  CLIENT-SIDE SETTINGS", left + 17, top + 30, 0xFFB8B8C9, false);
        g.text(this.font, "LOCAL CONFIG", left + panelW - 114, top + 22, accent, true);
        g.text(this.font, "CATEGORIES", left + 15, top + 67, accent, true);
        g.text(this.font, selected.toUpperCase(Locale.ROOT), sideRight + 16, top + 67, 0xFFF4F4FA, true);
        g.fill(sideRight + 16, top + 82, left + panelW - 16, top + 83, 0xFF373744);

        int tx = contentX();
        int ty = contentY() - 25;
        switch (selected) {
            case "Overview" -> {
                g.text(this.font, "Welcome back", tx, ty, accent, true);
                g.text(this.font, "Quick controls for your current SkyBlock session.", tx, ty + 18, 0xFFD0D0DA, false);
                g.text(this.font, "Theme: " + SfpConfig.INSTANCE.hudTheme, tx, ty + 40, 0xFFBEBED0, false);
                g.text(this.font, "Focus: " + SlayerTracker.focusSkill, tx, ty + 54, 0xFFBEBED0, false);
                g.text(this.font, "Session: " + formatDuration(SlayerTracker.sessionSeconds()), tx + 180, ty + 54, 0xFFBEBED0, false);
            }
            case "HUD" -> {
                g.text(this.font, "Pick exactly which lines appear in your overlay.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "Settings save automatically when toggled.", tx, ty + 15, 0xFF9999AE, false);
            }
            case "Appearance" -> {
                g.text(this.font, "Change accent colors and reposition the overlay.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "HUD position: X " + SfpConfig.INSTANCE.hudX + "  /  Y " + SfpConfig.INSTANCE.hudY,
                        tx, ty + 17, 0xFFBEBED0, false);
            }
            case "Skills" -> {
                g.text(this.font, "Choose Auto to infer a focus from your held tool.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "Detection is a guess, not an authoritative skill API.", tx, ty + 17, 0xFFBEBED0, false);
                g.text(this.font, "Current detected activity: " + SlayerTracker.activity, tx, ty + 34, 0xFFBEBED0, false);
            }
            case "Progression" -> {
                g.text(this.font, "A manual early-to-mid-game roadmap. Click a row to mark it complete.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "Completed: " + SfpConfig.completedMilestones() + "/" + PROGRESSION_GOALS.length, tx, ty + 17, accent, true);
                g.text(this.font, "Your checklist is saved locally; nothing is auto-completed.", tx, ty + 34, 0xFF9999AE, false);
            }
            case "Slayer" -> {
                g.text(this.font, "Read-only helpers for information visible in-game.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "Estimated kills may be inaccurate when XP varies.", tx, ty + 17, 0xFFFFD477, false);
                g.text(this.font, "Bosses this session: " + SlayerTracker.bossesKilled, tx, ty + 34, 0xFFBEBED0, false);
            }
            case "Coin Goal" -> {
                g.text(this.font, "Current coins (full number or K/M/B, e.g. 1.5m)", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, "Target coins", tx, ty + 47, 0xFFCDCDDA, false);
                g.text(this.font, goalStatus, tx, ty + 151, accent, true);
                g.text(this.font, "This calculator does not read your purse automatically.", tx, ty + 170, 0xFF9999AE, false);
            }
            case "Reminder" -> {
                g.text(this.font, "Write a short personal note for your session.", tx, ty, 0xFFCDCDDA, false);
                g.text(this.font, reminderStatus, tx, ty + 101, accent, false);
            }
            case "About" -> {
                g.text(this.font, "A beginner-friendly Fabric 26.2 template.", tx, ty, accent, true);
                g.text(this.font, "Local HUD • skill focus • coin goal • reminders", tx, ty + 19, 0xFFCDCDDA, false);
                g.text(this.font, "No macros, auto-clicking, movement automation,", tx, ty + 42, 0xFFCDCDDA, false);
                g.text(this.font, "packet manipulation, or remote profile scraping.", tx, ty + 56, 0xFFCDCDDA, false);
                g.text(this.font, "Check Hypixel's current rules before using any mod.", tx, ty + 82, 0xFFFFD477, false);
            }
        }

        // Small footer note for anyone learning the code.
        g.text(this.font, "Tip: edit SfpConfig.java to change defaults.", left + 13, top + panelH - 21, 0xFF86869C, false);
    }

    private static String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return hours > 0 ? String.format("%d:%02d:%02d", hours, minutes, secs)
                : String.format("%02d:%02d", minutes, secs);
    }
}
