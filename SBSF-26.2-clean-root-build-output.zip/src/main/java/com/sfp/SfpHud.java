package com.sfp;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/** Draws the configurable local overlay. It only renders data; it does not automate gameplay. */
public final class SfpHud {
    private static final DecimalFormat NUM = new DecimalFormat("#,##0");

    private record HudLine(String text, int color, boolean shadow) {}

    private SfpHud() {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        SfpConfig c = SfpConfig.INSTANCE;
        Minecraft mc = Minecraft.getInstance();
        if (!c.hudEnabled || mc.player == null || mc.level == null) return;

        // Build the visible lines first. This lets the background grow or shrink with the options.
        List<HudLine> lines = new ArrayList<>();
        int accent = SfpConfig.accentColor();
        lines.add(new HudLine("SBSF  /  SKYBLOCK ASSISTANT", accent, true));

        if (c.showActivity) {
            lines.add(new HudLine("Activity: " + SlayerTracker.activity, 0xFFF0F0F7, true));
            lines.add(new HudLine("Focus: " + SlayerTracker.focusSkill, 0xFFD3C1FF, true));
        }
        if (c.showCoins) {
            String purse = SlayerTracker.coins < 0
                    ? "Purse: not detected in visible text"
                    : "Purse: " + NUM.format(SlayerTracker.coins);
            lines.add(new HudLine(purse, 0xFFFFD66B, true));
        }
        if (c.showXp) {
            String xp = SlayerTracker.skillXp < 0
                    ? "Skill XP: not detected"
                    : "Detected XP: " + NUM.format(SlayerTracker.skillXp);
            lines.add(new HudLine(xp, 0xFF74DFFF, true));
        }
        if (c.showSlayer && SlayerTracker.active) {
            lines.add(new HudLine(SlayerTracker.slayer + " " + SlayerTracker.tier, 0xFFF0F0F7, true));
            lines.add(new HudLine(SlayerTracker.bossSpawned
                    ? "Boss spawned!"
                    : "Spawn estimate: " + SlayerTracker.killsLeft() + " kills",
                    SlayerTracker.bossSpawned ? 0xFFFF7777 : 0xFF7AF0B0, true));
        }
        if (c.showProgression) {
            lines.add(new HudLine("Milestones: " + SfpConfig.completedMilestones() + "/8 completed", 0xFF8BE8BD, true));
        }
        if (c.showGoal) {
            long current = c.currentCoins;
            long target = c.targetCoins;
            String goal = current >= target ? "Coin goal reached! " + NUM.format(target)
                    : "Coin goal: " + NUM.format(current) + " / " + NUM.format(target)
                    + " (" + NUM.format(SfpConfig.coinsRemaining()) + " left)";
            lines.add(new HudLine(goal, 0xFFFFD66B, true));
        }
        if (c.showReminder && !c.reminder.isBlank()) {
            String reminder = c.reminder.trim();
            if (reminder.length() > 48) reminder = reminder.substring(0, 45) + "...";
            lines.add(new HudLine("Reminder: " + reminder, 0xFFE0E0EA, false));
        }
        if (c.showTips) {
            String tip = SlayerTracker.tip == null ? "Choose a focus in /sbsf" : SlayerTracker.tip;
            if (tip.length() > 52) tip = tip.substring(0, 49) + "...";
            lines.add(new HudLine("Tip: " + tip, 0xFFD8D8E2, false));
        }
        if (c.showSession) {
            lines.add(new HudLine("Session: " + formatDuration(SlayerTracker.sessionSeconds()), 0xFFBFC5D6, false));
        }
        if (c.showBossCount) {
            lines.add(new HudLine("Bosses this session: " + SlayerTracker.bossesKilled, 0xFFFFEE99, true));
        }

        int lineHeight = c.compactHud ? 10 : 12;
        int textWidth = 0;
        for (HudLine line : lines) textWidth = Math.max(textWidth, mc.font.width(line.text()));
        // Clamp at render time too, so a resolution change cannot strand the HUD off-screen.
        int x = Math.max(2, Math.min(c.hudX, Math.max(2, mc.getWindow().getGuiScaledWidth() - 80)));
        int y = Math.max(2, Math.min(c.hudY, Math.max(2, mc.getWindow().getGuiScaledHeight() - 24)));
        int panelWidth = Math.min(Math.max(180, textWidth + 16), Math.max(180, mc.getWindow().getGuiScaledWidth() - x - 4));
        int panelHeight = 8 + lines.size() * lineHeight;

        // Background and accent bar use ARGB colors (0xAARRGGBB).
        g.fill(x - 4, y - 4, x + panelWidth, y + panelHeight, c.compactHud ? 0xA8101017 : 0xB814141D);
        g.fill(x - 4, y - 4, x + panelWidth, y - 2, accent);

        int textY = y;
        for (HudLine line : lines) {
            g.text(mc.font, line.text(), x, textY, line.color(), line.shadow());
            textY += lineHeight;
        }
    }

    private static String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return hours > 0 ? String.format("%d:%02d:%02d", hours, minutes, secs)
                : String.format("%02d:%02d", minutes, secs);
    }
}
