package com.sfp;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Read-only parser for information already visible in the client's scoreboard and held item.
 *
 * NOTE: This is a lightweight template tracker. Hypixel does not expose every skill XP or purse
 * value in a consistent sidebar format, so values can be missing. Activity detection is heuristic.
 * No gameplay actions or server commands are automated.
 */
public final class SlayerTracker {
    private static final Pattern QUEST = Pattern.compile("(Revenant Horror|Tarantula Broodfather|Sven Packmaster|Voidgloom Seraph|Inferno Demonlord|Riftstalker Bloodfiend)\\s+([IVX]+)");
    private static final Pattern PROGRESS = Pattern.compile("\\(([\\d,.]+[kKmM]?)/([\\d,.]+[kKmM]?)\\)\\s*(Combat XP|Kills)");
    private static final Pattern COINS = Pattern.compile("([\\d,]+(?:\\.\\d+)?[kKmMbB]?)\\s*(?:coins|purse)", Pattern.CASE_INSENSITIVE);
    private static final String[] SKILLS = {"Mining", "Fishing", "Farming", "Foraging", "Combat", "Enchanting", "Alchemy", "Taming"};
    private static final String[] TIPS_MINING = {"Try a mining route that matches your gear and powder.", "Check your mining speed and fortune before a long session.", "Compare bazaar sell prices before choosing an ore route."};
    private static final String[] TIPS_FISHING = {"Use a fishing spot suited to your current fishing level.", "Check your rod, bait, and sea-creature chance.", "Try a different fishing area if catches slow down."};
    private static final String[] TIPS_FARMING = {"Keep your farm route consistent to measure XP/hour.", "Check crop prices before deciding what to farm.", "Use a tool and equipment set suited to your crop."};
    public static boolean active, bossSpawned;
    public static String slayer = "", tier = "", activity = "Unknown", focusSkill = "Mining", tip = "Choose a skill focus in /sbsf";
    public static double xp, xpNeeded, lastGain, coins = -1, skillXp = -1;
    public static int bossesKilled;
    private static boolean alerted;
    private static int tick, tipIndex;
    private static double lastX, lastY, lastZ;
    private static final long SESSION_START_MS = System.currentTimeMillis();
    private static long lastActivityMs = System.currentTimeMillis();

    // Called from the client tick event. Parse every fifth tick to reduce repeated string work.
    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) { active = false; return; }
        if (++tick % 5 != 0) return;
        updateMovement(mc);
        // Read the sidebar text currently rendered by the server; it may be absent or formatted differently.
        List<String> lines = sidebar(mc);
        boolean wasBoss = bossSpawned, found = false, progress = false;
        bossSpawned = false;
        coins = -1;
        for (String line : lines) {
            String clean = line.replaceAll("§.", "").trim();
            Matcher q = QUEST.matcher(clean);
            if (q.find()) { slayer = q.group(1); tier = q.group(2); found = true; }
            Matcher p = PROGRESS.matcher(clean);
            if (p.find()) {
                double cur = parse(p.group(1)), need = parse(p.group(2));
                if (cur > xp && xp > 0 && need == xpNeeded) lastGain = cur - xp;
                xp = cur; xpNeeded = need; progress = true;
            }
            Matcher coin = COINS.matcher(clean);
            if (coin.find()) coins = parse(coin.group(1));
            if (clean.toLowerCase(Locale.ROOT).contains("slay the boss")) bossSpawned = true;
            if (clean.toLowerCase(Locale.ROOT).contains("slayer quest")) found = true;
            for (String skill : SKILLS) {
                if (clean.toLowerCase(Locale.ROOT).contains(skill.toLowerCase(Locale.ROOT)) &&
                    (clean.toLowerCase(Locale.ROOT).contains("xp") || clean.matches(".*\\b\\d+\\b.*"))) {
                    focusSkill = skill;
                    Matcher sm = Pattern.compile("([\\d,.]+)\\s*(?:/\\s*[\\d,.]+)?\\s*XP", Pattern.CASE_INSENSITIVE).matcher(clean);
                    if (sm.find()) skillXp = parse(sm.group(1));
                }
            }
        }
        if (wasBoss && !bossSpawned && found && !progress) bossesKilled++;
        active = found;
        if (!found) { xp = 0; lastGain = 0; alerted = false; }
        boolean ready = found && !progress && !bossSpawned && xpNeeded > 0;
        if (progress) alerted = false;
        if (ready && !alerted && SfpConfig.INSTANCE.bossAlert) {
            alerted = true;
            mc.player.sendSystemMessage(Component.literal("[SBSF] Slayer progress looks ready — check your quest."));
        }
        detectActivity(mc);
        chooseTip();
    }

    // Track movement, item use, and swinging as a simple activity timer for AFK reminders.
    private static void updateMovement(Minecraft mc) {
        var p = mc.player;
        double dx = p.getX()-lastX, dy = p.getY()-lastY, dz = p.getZ()-lastZ;
        if (Math.abs(dx)+Math.abs(dy)+Math.abs(dz) > 0.02 || p.swinging || p.isUsingItem()) lastActivityMs = System.currentTimeMillis();
        lastX=p.getX(); lastY=p.getY(); lastZ=p.getZ();
    }
    // Guess the current activity from the held item name.
    // This is intentionally simple and can misidentify activities if the player holds a general-purpose item.
    private static void detectActivity(Minecraft mc) {
        String held = mc.player.getMainHandItem().getHoverName().getString().toLowerCase(Locale.ROOT);
        if (held.contains("fishing rod") || held.contains("rod of")) activity = "Fishing";
        else if (held.contains("pickaxe") || held.contains("drill") || held.contains("gauntlet") || held.contains("mattock")) activity = "Mining";
        else if (held.contains("hoe") || held.contains("cultivator") || held.contains("dicer")) activity = "Farming";
        else if (held.contains("axe") || held.contains("treecapitator")) activity = "Foraging";
        else if (held.contains("sword") || held.contains("bow") || held.contains("dagger")
                || held.contains("claymore") || held.contains("trident")) activity = "Combat";
        else if (!held.isBlank()) activity = "General";
        else activity = "Unknown";
        SfpConfig c = SfpConfig.INSTANCE;
        focusSkill = c.focusSkill.equalsIgnoreCase("Auto") ? activity : c.focusSkill;
    }
    // Select a built-in contextual suggestion. These are rule-based tips, not AI-generated advice.
    private static void chooseTip() {
        if (SfpConfig.INSTANCE.afkTips && System.currentTimeMillis()-lastActivityMs >= SfpConfig.INSTANCE.afkTimeoutSeconds*1000L) {
            tip = "Idle for " + SfpConfig.INSTANCE.afkTimeoutSeconds + "s+. Check your goal or take a break."; return;
        }
        String[] tips = switch (focusSkill) {
            case "Mining" -> TIPS_MINING; case "Fishing" -> TIPS_FISHING; case "Farming" -> TIPS_FARMING;
            case "Combat" -> new String[]{"Compare combat XP routes with your gear and survivability.", "Check your bestiary and combat milestones.", "Try a different activity if the current route feels slow."};
            case "Foraging" -> new String[]{"Compare wood prices before choosing a tree route.", "Check your axe and speed setup.", "Track a short session to estimate your own XP/hour."};
            default -> new String[]{"Pick a main skill in /sbsf to focus your HUD.", "Check your coins and choose a goal for this session.", "If bored, try a collection milestone or a short quest."};
        };
        tip = tips[(tipIndex++ / 12) % tips.length];
    }
    /** Seconds since this client-side mod session started. This is not the player's total playtime. */
    public static long sessionSeconds() {
        return Math.max(0L, (System.currentTimeMillis() - SESSION_START_MS) / 1000L);
    }

    // Estimate remaining kills only after a positive XP gain has been observed.
    // The estimate is rough because XP per kill can vary.
    public static String killsLeft() {
        if (xpNeeded <= 0) return "unknown";
        if (lastGain <= 0) return "calibrating";
        return "~" + Math.max(0, (int)Math.ceil((xpNeeded-xp)/lastGain));
    }
    // Extract visible scoreboard entry text. This is not a SkyCrypt/API lookup.
    private static List<String> sidebar(Minecraft mc) {
        List<String> out = new ArrayList<>(); Scoreboard sb = mc.level.getScoreboard();
        Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR); if (obj == null) return out;
        for (PlayerScoreEntry e : sb.listPlayerScores(obj)) {
            PlayerTeam team = sb.getPlayersTeam(e.owner());
            out.add(PlayerTeam.formatNameForTeam(team, e.ownerName()).getString());
        }
        return out;
    }
    // Convert strings like 1,234, 2.5k, or 3m into numeric values.
    private static double parse(String s) {
        s=s.replace(",", ""); double mult=1;
        char c=Character.toLowerCase(s.charAt(s.length()-1));
        if(c=='k'){mult=1_000;s=s.substring(0,s.length()-1);} else if(c=='m'){mult=1_000_000;s=s.substring(0,s.length()-1);} else if(c=='b'){mult=1_000_000_000;s=s.substring(0,s.length()-1);}
        try{return Double.parseDouble(s)*mult;}catch(Exception e){return 0;}
    }
}
