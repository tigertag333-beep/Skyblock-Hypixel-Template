package com.sfp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * All user-editable options in one place.
 *
 * Beginner note: the fields here are the settings. The GUI changes these values, the HUD reads
 * them, and save() writes them to a local JSON file. No settings are uploaded anywhere.
 */
public final class SfpConfig {
    // HUD visibility switches. These can be changed in /sbsf > HUD.
    public boolean hudEnabled = true;
    public boolean showActivity = true;
    public boolean showXp = true;
    public boolean showCoins = true;
    public boolean showTips = true;
    public boolean showSession = true;
    public boolean showSlayer = true;
    public boolean showGoal = true;
    public boolean showReminder = true;
    public boolean showBossCount = true;
    public boolean showProgression = true;
    public boolean compactHud = false;

    // Manual early-to-mid-game milestones. The player marks these; SBSF does not inspect hidden data.
    // Keep the number/order aligned with SfpScreen.PROGRESSION_GOALS.
    public boolean[] progressionDone = new boolean[8];

    // Slayer and inactivity reminders.
    public boolean bossAlert = true;
    public boolean afkTips = true;
    public int afkTimeoutSeconds = 30;

    // HUD coordinates are screen pixels. The Appearance page can nudge them around.
    public int hudX = 8;
    public int hudY = 8;

    // Saved customization. Names match the options shown in the GUI.
    public String focusSkill = "Auto";
    public String hudTheme = "Purple";

    // Manually-entered values for the coin-goal calculator; they are not the live purse.
    public long currentCoins = 0L;
    public long targetCoins = 100_000_000L;

    // A simple reminder written by the player.
    public String reminder = "Collect minions";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("slayersforpros.json");

    public static SfpConfig INSTANCE = new SfpConfig();

    /** Load saved settings on startup; defaults are retained if the file is missing. */
    public static void load() {
        try {
            if (Files.exists(FILE)) {
                SfpConfig loaded = GSON.fromJson(Files.readString(FILE), SfpConfig.class);
                if (loaded != null) INSTANCE = loaded;
            }
        } catch (Exception exception) {
            // Keep defaults if the file was edited by hand and became invalid.
            System.err.println("[SBSF] Could not read config; using defaults: " + exception.getMessage());
        }

        // Older configs may not contain the newer fields, so normalize nullable text settings.
        if (INSTANCE == null) INSTANCE = new SfpConfig();
        if (INSTANCE.focusSkill == null || INSTANCE.focusSkill.isBlank()) INSTANCE.focusSkill = "Auto";
        if (INSTANCE.hudTheme == null || INSTANCE.hudTheme.isBlank()) INSTANCE.hudTheme = "Purple";
        if (INSTANCE.reminder == null) INSTANCE.reminder = "";
        // Gson leaves newly-added arrays null when loading an older config, so restore safe defaults.
        if (INSTANCE.progressionDone == null || INSTANCE.progressionDone.length != 8) {
            boolean[] migrated = new boolean[8];
            if (INSTANCE.progressionDone != null) {
                System.arraycopy(INSTANCE.progressionDone, 0, migrated, 0,
                        Math.min(INSTANCE.progressionDone.length, migrated.length));
            }
            INSTANCE.progressionDone = migrated;
        }
        INSTANCE.afkTimeoutSeconds = Math.max(5, Math.min(600, INSTANCE.afkTimeoutSeconds));
        INSTANCE.hudX = Math.max(2, Math.min(3000, INSTANCE.hudX));
        INSTANCE.hudY = Math.max(2, Math.min(3000, INSTANCE.hudY));
        INSTANCE.currentCoins = Math.max(0, INSTANCE.currentCoins);
        INSTANCE.targetCoins = Math.max(0, INSTANCE.targetCoins);
    }

    /** Persist the current settings locally. */
    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (Exception exception) {
            System.err.println("[SBSF] Could not save config: " + exception.getMessage());
        }
    }

    /** Return the ARGB accent color for one of the built-in themes. */
    public static int accentColor() {
        return switch (INSTANCE.hudTheme.toLowerCase()) {
            case "sky blue", "skyblue", "blue" -> 0xFF57C7FF;
            case "mint", "green" -> 0xFF5DE2B2;
            case "gold", "yellow" -> 0xFFFFC857;
            default -> 0xFFB76CFF;
        };
    }

    /** Count manually checked milestones for the HUD and progression page. */
    public static int completedMilestones() {
        int count = 0;
        if (INSTANCE.progressionDone != null) {
            for (boolean done : INSTANCE.progressionDone) if (done) count++;
        }
        return count;
    }

    /** Calculate the remaining manually-entered coin goal without overflowing on subtraction. */
    public static long coinsRemaining() {
        return Math.max(0L, INSTANCE.targetCoins - Math.min(INSTANCE.currentCoins, INSTANCE.targetCoins));
    }
}
