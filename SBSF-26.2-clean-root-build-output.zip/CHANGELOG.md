# Changelog

## 1.1.0 — SBSF quality-of-life update
- Set the main build artifact filename to `sbsf.jar`.
- Corrected Fabric 26.2 non-remapping Loom dependency configurations to `implementation`.
- Added a persistent eight-step early/mid-game progression checklist and HUD progress line.
- Added config migration for the new checklist setting.
- Improved HUD coordinate clamping after screen-size changes.
- Updated display branding and beginner documentation.
