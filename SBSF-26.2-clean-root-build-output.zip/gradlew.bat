@echo off
setlocal
rem SBSF bootstrap launcher: downloads Gradle 9.5.1 to the user's cache on first use.
set "GRADLE_VERSION=9.5.1"
if defined GRADLE_USER_HOME (
  set "CACHE_ROOT=%GRADLE_USER_HOME%\sbsf-bootstrap"
) else (
  set "CACHE_ROOT=%USERPROFILE%\.gradle\sbsf-bootstrap"
)
set "GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  echo SBSF: Gradle %GRADLE_VERSION% is not cached; downloading it now...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z='%CACHE_ROOT%\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -Uri $u -OutFile $z; Expand-Archive -LiteralPath $z -DestinationPath '%CACHE_ROOT%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
